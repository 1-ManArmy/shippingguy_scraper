import os
import re
import json
import random
import asyncio
from pathlib import Path
from playwright.async_api import async_playwright

CONFIG = {
    "target_url": "https://www.PROFESSORJOHNNY.com/",
    "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/91.0.4472.124 Safari/537.36",
    "download_dir": Path(__file__).parent / "downloads-viogogo",
    "max_depth": 15
}

visited = set()
results = {
    "pages": [],
    "cookies": [],
    "endpoints": [],
    "api_keys": [],
    "resources": []
}

def log(msg, *args):
    print(f"[{__import__('datetime').datetime.now().isoformat()}] {msg}", *args)

async def download_resource(session, url, file_path):
    try:
        import requests
        r = session.get(url, stream=True, timeout=20)
        with open(file_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
        log(f"📦 Downloaded: {file_path.name}")
    except Exception as e:
        log(f"❌ Failed to download {url}: {e}")

async def crawl(page, url, depth=0, session=None):
    if url in visited or depth > CONFIG["max_depth"]:
        return
    visited.add(url)

    log(f"🌐 Crawling: {url} (depth {depth})")
    try:
        await page.goto(url, wait_until="domcontentloaded", timeout=30000)
    except Exception as err:
        log(f"❌ Failed to load: {url} ({err})")
        return
    await asyncio.sleep(2)

    # Collect links
    links = await page.eval_on_selector_all(
        "a",
        "as => as.map(a => a.href).filter(href => href && href.startsWith('https://www.PROFESSORJOHNNY.com/') && !href.includes('#'))"
    )

    # Collect hidden elements
    hidden_elements = await page.evaluate(
        "() => Array.from(document.querySelectorAll('div[style*=\"display: none\"]')).map(el => el.textContent.trim())"
    )

    # Collect cookies
    cookies = await page.context.cookies()
    results["cookies"].extend(cookies)

    # Collect endpoints
    endpoints = [href for href in links if "auth" in href]
    results["endpoints"].extend(endpoints)

    # Collect API keys
    page_content = await page.content()
    matches = re.findall(r"(api_key|token|secret)=([A-Za-z0-9_\-]+)", page_content, re.I)
    api_keys = [m[1] for m in matches]
    results["api_keys"].extend(api_keys)

    # Collect downloadable resources
    resources = await page.eval_on_selector_all(
        "a",
        "as => as.map(a => a.href).filter(href => /\\.(jpg|png|pdf|docx|zip)$/i.test(href))"
    )
    results["resources"].extend(resources)

    # Save page data
    results["pages"].append({
        "url": url,
        "links": links,
        "hidden_elements": hidden_elements,
        "endpoints": endpoints,
        "api_keys": api_keys,
        "resources": resources
    })

    # Download resources
    import requests
    for resource in resources:
        file_name = os.path.basename(resource.split("?")[0])
        file_path = CONFIG["download_dir"] / file_name
        await download_resource(requests, resource, file_path)

    await asyncio.sleep(1 + random.random() * 2)  # Random delay

    # Recursively crawl internal links
    for link in links:
        if link not in visited:
            await crawl(page, link, depth + 1, session)

async def main():
    log("🚀 Automation started: Ninja Spider (Python)")
    CONFIG["download_dir"].mkdir(exist_ok=True)
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=True,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--disable-infobars",
                "--start-maximized"
            ]
        )
        context = await browser.new_context(
            user_agent=CONFIG["user_agent"],
            viewport={"width": 1600, "height": 900},
            ignore_https_errors=True
        )
        page = await context.new_page()

        try:
            await crawl(page, CONFIG["target_url"])
            # Save all results
            out_file = CONFIG["download_dir"] / "fullsite_results.json"
            with open(out_file, "w", encoding="utf-8") as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            log("✅ Full site crawl complete!")
        except Exception as err:
            log(f"❌ Error during crawl: {err}")
        finally:
            await browser.close()
            log("🛑 Automation finished. Browser closed.")

if __name__ == "__main__":
    asyncio.run(main())